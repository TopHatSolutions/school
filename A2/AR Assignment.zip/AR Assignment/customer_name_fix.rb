####################################################
# Name: Andrew Gillespie                           #
# Assignment: 2 - Part 1                           #
# Description: This will loop through the customer #
# table and take the first name value of customers #
# with no last name value, and split by ' ' and    #
# populate it properly.                            #
# Woo!                                             #
####################################################
load 'ar.rb'

customers = Customer.all
i = 1
customers.each do |c|
  puts "Entry ##{i}"
  if c.last_name == nil
    #puts c.inspect
    name = c.first_name.split(' ')
    c.first_name = name[0]
    c.last_name = name[1]
    #puts "First Name: #{c.first_name}"
    #puts "Last Name: #{c.last_name}"
    if c.save
      puts "Save successful"
    else
      puts "Save failed:"
      c.errors.messages.each do |column, errors|
        errors.each do |error|
          puts "The #{column} property #{error}."
        end
      end
    end
  else
    puts "Name is already fixed"
  end
  #puts "New Data: #{c.inspect}"
  i = i+1
end
